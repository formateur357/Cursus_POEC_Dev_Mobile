/* on mémorise l'emplacement de la case vide */
var erow = 2;
var ecol = 2;
var nombreClics = 0;


var shuffle = function() {
  bougeblock = 0;
  var movescell.innerHTML = bougeblock; // update # of moves displayed
  [erow, erowCol] = [2, 2]; 
var numeros= [ [0,0], [0,1], [0,2], [1,0], [1,1], [1,2], [2,0], [2,1], [2, 2] ];

var block = [block00, block01, block02, block10, block11, block12, block20, block21, block22];

for(let i=8; i>=0; i--) {
  let r = Math.round(Math.random() * i); // random integer from 0 to i
  let poppedPos = positions.splice(r, 1); // removes an element from "positions" array at "r" position
  block[i].style.gridRow = poppedPos[0][0];
  block[i].style.gridColumn = poppedPos[0][1];
}

}

/* Fonction qui échange la case (row,col) avec la case vide */
function bouge(row, col) {
  if (
    (erow == row && (col == ecol - 1 || col == ecol + 1)) ||
    (ecol == col && (row == erow - 1 || row == erow + 1))
  ) {
    /* mise à jour du nombre de clics */
    nombreClics += 1;

    /* on récupère l'élément compteur */
    var noeud_compteur = document.getElementById("compteur");
    noeud_compteur.innerHTML =
      nombreClics == 1 ? nombreClics + " coup!!" : nombreClics + " coups!!";

    /*var bouton = chercherCaseVide();
  var result = " row = " + row + " col = " + col + " bouton.id " + bouton.id;
  alert(result);
  return result;*/

    // // // /* créer un nouveau noeud textuel avec la valeur nbclicks */
    // var compteur_txt;
    // if (nbclicks == 1) {
    //     compteur_txt = document.createTextNode('un seul coup joué');
    // } else {
    //     compteur_txt = document.createTextNode(nbclicks + ' coups joués');
    // }

    // noeud_compteur.innerHTML = "";

    // // /* ajouter ce noeud textuel comme fils de l'élément compteur */
    // noeud_compteur.appendChild(compteur_txt);

    /* on récupère les identifiants des deux boutons concernés */

    var casepleine = "block" + row + col;
    var casevide = "block" + erow + ecol;

    /* on récupère les noeuds correspondant à ces boutons */
    var pnoeud = document.getElementById(casepleine);
    var enoeud = document.getElementById(casevide);

    /* on peut directement utiliser un tampon afin de switcher les deux texte */
    var tmp = pnoeud.innerHTML;
    pnoeud.innerHTML = enoeud.innerHTML;
    enoeud.innerHTML = tmp;

    /* on récupère les fils textuels des deux boutons */
    //var pvalue = pnoeud.removeChild(pnoeud.childNodes[0]);
    //var evalue = enoeud.removeChild(enoeud.childNodes[0]);

    /* on échange ces fils */
    //pnoeud.appendChild(evalue);
    //enoeud.appendChild(pvalue);

    /* on échange les classes des deux boutons */
    /* on échange les classes des deux boutons */
    document.getElementById("block" + row + col).setAttribute("class", "empty");
    document
      .getElementById("block" + erow + ecol)
      .setAttribute("class", "piece");

    /* on enlève le "focus" sur le bouton cliqué */
    // pnoeud.blur();

    /* on mémorise l'emplacement de la case vide */
    erow = row;
    ecol = col;

    /* ajouter ce noeud textuel comme fils de l'élément compteur */
    //noeud_compteur.appendChild(compteur_txt);
  
  
  
  }
 


}

/*function bouge1(row, col, uk, po) {
  let result = "" + row + col + uk + po;
  //alert(result);
  alert("" + row + col + uk + po);
  return result;
}*/

/*function chercherCaseVide() {
  let result;
  let casesvides = document.getElementsByClassName("empty");
  //mettre container si on a cherché id=puzzle
  result = casesvides[0];
  return result;
}*/

/*Mélanger aléatoirement les cases au début du jeu.
Détecter la fin de partie.
Adapter le jeu à une version avec les morceaux d'une photo, plutôt qu'avec des boutons*/